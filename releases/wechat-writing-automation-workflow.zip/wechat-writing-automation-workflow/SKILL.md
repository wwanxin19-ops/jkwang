---
name: wechat-writing-automation-workflow
description: "Use when the user asks for a complete WeChat Official Account writing automation workflow: hot topic research, topic selection, viral article writing, premium collage cover generation, baoyu-infographic inline illustrations, WeChat formatting/preflight, and draft-box upload. Integrates wechat-daily-ai-draft-pipeline and wechat-collage-cover into one optimized end-to-end workflow."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [wechat, writing, automation, draft-box, collage-cover, infographic, publishing]
    related_skills: [wechat-boom-content, wechat-collage-cover, wechat-baoyu-infographic-illustrations, baoyu-infographic, baoyu-social-publishing, baoyu-content-workflow, wechat-daily-ai-draft-pipeline]
---

# 微信公众号写作自动化工作流

## Overview

这个 skill 是“微信公众号写作自动化工作流”的总包：把 `wechat-daily-ai-draft-pipeline` 的“今日热点 → 文章 → 信息图 → 草稿箱”能力，和 `wechat-collage-cover` 的“高级拼贴风公众号封面”能力合并成一个更清晰、更少返工的端到端流程。

目标不是只写一篇文章，而是产出一套可以直接进入公众号草稿箱的发布资产：

- 选题有依据；
- 标题有点击欲；
- 正文能读、能转发；
- 封面有高级视觉锤；
- 正文插图是用户偏好的 baoyu 信息图风格；
- 微信渲染预检通过；
- 草稿箱真实上传并返回 `media_id`。

核心原则：**少问、快跑、真上传、有日志、可回滚。** 用户已经给出文章范围和凭据可用时，不要在同一流程里反复确认上传。

## Primary Workflow Policy

从 **v1.0.0** 开始，本 skill 是用户默认的微信公众号写作主工作流。以后只要用户提出“写公众号文章 / 做公众号爆款 / 今日AI热点成稿 / 上传公众号草稿箱 / 生成封面和插图”等完整或半完整公众号任务，优先加载并执行本 skill。

旧的窄技能仍可作为子模块调用：

- `wechat-boom-content`：负责选题和爆款写作逻辑；
- `wechat-collage-cover`：负责高级拼贴风封面；
- `wechat-baoyu-infographic-illustrations` / `baoyu-infographic`：负责正文信息图；
- `baoyu-social-publishing`：负责微信预检和草稿箱上传；
- `wechat-daily-ai-draft-pipeline`：只作为历史流程参考和兼容层，不再作为默认主入口。

---

## When to Use

当用户提出以下需求时使用：

- “做一篇公众号文章 / 写公众号爆款 / 按今天AI热点跑一遍流程”
- “从选题到草稿箱全流程”
- “生成公众号封面 + 正文插图 + 上传草稿箱”
- “用 wechat-daily-ai-draft-pipeline 跑，但封面用 wechat-collage-cover”
- “帮我自动化公众号写作流程 / 封装公众号工作流”
- “替换封面 / 替换插图 / 重新上传新版草稿”

不要用于：

- 只需要普通聊天回答，不需要文章资产；
- 只生成单张图片，不写文章；
- 只做技术代码任务；
- 微信凭据不可用且用户也没有授权上传时。此时只产出 ready-to-upload 文件和 blocker handoff。

---

## Skill Stack

固定组合使用这些 skills：

| 阶段 | Skill | 用途 |
|---|---|---|
| 热点采集 / 爆款选题 | `wechat-boom-content` | 今日热点、选题筛选、标题和爆款逻辑 |
| 主流程骨架 | `wechat-daily-ai-draft-pipeline` | 今日 AI 热点到草稿箱的端到端约束 |
| 封面 | `wechat-collage-cover` | 高级手撕拼贴 / 视觉杂志感公众号封面 |
| 正文信息图 | `wechat-baoyu-infographic-illustrations` | 1080×608 正文信息图插图 |
| 信息图规范 | `baoyu-infographic` | `dense-modules + craft-handmade` 规范 |
| 内容处理 | `baoyu-content-workflow` | Markdown/HTML/URL 抓取/格式辅助 |
| 草稿箱上传 | `baoyu-social-publishing` | `md-to-wechat.ts`、`wechat-api.ts`、WeChat API 上传 |

---

## Directory Pattern

每篇文章必须创建独立目录：

```text
/home/lighthouse/.hermes/profiles/gzhao-agent/home/wechat-drafts/<topic-slug>-<YYYYMMDD>/
├── article.md
├── article-v2.md
├── draft-metadata.md
├── imgs/
│   ├── cover-collage-<topic>-<YYYYMMDD>.jpg
│   ├── cover-collage-<topic>-<YYYYMMDD>-4k-master.jpg
│   ├── inline-v1-01-real-baoyu-infographic-<topic>-<YYYYMMDD>.jpg
│   ├── inline-v1-01-real-baoyu-infographic-<topic>-<YYYYMMDD>-4k-master.jpg
│   └── ...
├── prompts/
│   ├── 01-cover-collage-<topic>.md
│   ├── 02-inline-<topic>.md
│   └── ...
├── logs/
│   ├── research-sources.md
│   ├── check-permissions.log
│   ├── render-v1-result.json
│   ├── render-v1-stderr.log
│   ├── upload-v1.stdout
│   ├── upload-v1.stderr
│   └── upload-v1.combined.log
└── .baoyu-skills/.env
```

命名硬规则：

- 每次重生封面或插图，都用新 basename，不覆盖旧文件；
- 封面文件必须包含 `cover-collage`；
- 正文信息图文件必须包含 `real-baoyu-infographic`；
- 4K master 只归档，不上传正文；
- 微信正文图上传版固定 **1080×608**；
- 微信封面上传版默认 **900×383** 或按当前文章上传脚本要求处理，必要时保留 1600×900 / 4K master 作为备份。

---

## Optimized End-to-End Workflow

### 0. 先判定任务模式

收到用户请求后，先归类：

| 用户输入 | 执行动作 |
|---|---|
| 只要“选题” | 做实时热点采集，输出 5-6 个选题，不写全文 |
| 每日定时/无人值守“选题采集” | 只采集并推送 5-6 个候选选题，等待用户回复编号/标题确认；不要自行选题成稿、不要生成图片、不要上传 |
| 已指定选题 | 跳过选题选择，直接写文章 + 视觉 + 上传 |
| 已有文章 | 不重写主题，做封面/插图/排版/上传 |
| 要改封面 | 只重生 `cover-collage`，预检后上传新版草稿 |
| 要改某张插图 | 只重生指定 `inline` 信息图，预检后上传新版草稿 |

默认少问，但不能跳过必要选择：

- 如果用户**已经明确指定选题/标题/素材**，直接进入成稿、视觉和上传；
- 如果用户只是说“写一篇公众号爆款 / 测试写一遍 / 今天热点成稿”但**没有指定具体选题**，必须先输出 5-6 个候选选题池，让用户选择编号或名称；
- 在用户选定话题前，不要擅自挑一个话题直接写全文；
- 对每日定时任务尤其要注意：默认每天只做“AI 热点候选池”，用户回复编号后再开启完整写作链路；除非用户明确把定时任务改成“自动成稿/自动上传”，否则不能无人值守自动拍板选题；
- 只有缺少主标题/主题且无法推断时才询问；如果能通过热点采集生成候选，就先给候选。

---

### 1. 实时采集与事实边界

如果用户说“今天 / 最新 / 热门 / AI热点”，必须先确认当前时间：

```bash
date '+%Y-%m-%d %H:%M:%S %Z'
```

至少交叉参考 3 个实时来源，优先：

- Hacker News / HN Algolia
- GitHub Trending
- TechCrunch AI / The Verge AI / Reuters 等新闻源
- 36氪 / 机器之心 / 雷峰网 / IT之家等中文科技源

输出或保存到 `logs/research-sources.md`：

- 话题名称；
- 来源 URL；
- 时间戳；
- 热度信号（points、comments、stars、votes、发布时间）；
- 事实可用性：可访问 / 被反爬 / 仅作背景；
- 写作可用结论。

**Blocked-source fallback:** 如果 Reuters/WSJ/Bloomberg 等被 401、JS challenge、付费墙阻断，不要编造细节。可用 HN Algolia 获取标题、原始 URL、points、created_at 等热度元数据，再找一个可访问来源交叉验证。文章里只写可验证信息，并明确“据 X 报道 / HN 热度显示”。

---

### 2. 选题与标题

用公众号爆款逻辑筛选主选题：

- 有冲突：巨头对立、价格变化、职业影响、规则变化；
- 有普通人视角：为什么和我有关；
- 有解释空间：能从“是什么”讲到“怎么办”；
- 不只是技术参数更新。

为主选题生成 3-5 个标题，优先使用：

| 标题公式 | 示例方向 |
|---|---|
| 巨头冲突 | `OpenAI突然亮出自研芯片：英伟达最担心的事，还是发生了` |
| 反直觉 | `AI没杀死程序员？最先拥抱AI的人反而最安全` |
| 规则变化 | `免费AI时代结束了？真正好用的AI开始明码标价` |
| 普通人利益 | `公司开始限制AI使用：不是AI没用，是账单炸了` |

如果用户已经指定标题，不要擅自换掉；最多给一个更爆款的优化版并说明。

---

### 3. 写公众号正文

文章默认作者：`jk铭点`。

文章结构建议：

```markdown
---
title: "..."
author: "jk铭点"
summary: "50-100字摘要，能做分享卡片"
cover: "imgs/cover-collage-xxx.jpg"
original: true
comments: true
---

# 标题

> 3秒抓人的开头金句 / 数据 / 冲突

## 先说结论

## 这件事到底是什么

## 为什么现在爆了

## 对普通人/行业有什么影响

## 接下来怎么办

## 最后一句话

评论区互动问题
```

写作风格：

- 通俗易懂，少堆术语；
- **开头第一屏尤其要白话**：不要写“我抓取到 / 采集显示 / F1 / IDOR / benchmark / harness / open-weight”等采集口吻或专业名词堆叠；先用普通读者能秒懂的话讲“发生了什么、为什么值得看”，技术细节放到后文再解释；
- 不要机械的一句话一段，把相关短句合并成 3-5 行自然段；
- 每个小节有明确推进：是什么 → 为什么 → 影响 → 行动；
- 关键结论加粗；
- 适合手机阅读，避免大段墙；
- 结尾必须有互动问题。

#### 3.1 正文表格处理规则

生成公众号正文时，**不要在文章内容里使用 Markdown 表格**（例如 `| 问题 | 影响 |` 这种写法）。原因：公众号移动端表格阅读体验差，复制到微信编辑器后也容易变形。

遇到适合表格表达的信息，例如：

- 对比项：A vs B、短期 vs 长期、免费版 vs 付费版；
- 结构项：问题 / 影响 / 解决办法；
- 清单项：角色 / 动作 / 结果；
- 数据项：时间 / 事件 / 信号；

默认改成两种形式之一：

1. **正文内用短段落或项目符号解释**，保持手机端可读；
2. **把表格内容转成正文信息图插图**，在文章中放置图片引用，例如：

```markdown
![三重压力](imgs/inline-v1-02-real-baoyu-infographic-three-pressure-YYYYMMDD.jpg)
```

对应信息图 prompt 应使用 `dense-modules + craft-handmade`，把原本表格的列转成 4-6 个模块。不要先在正文里放 Markdown 表格再额外配图；正文以“文字解释 + 信息图”承载结构化信息。

---

### 4. 封面：整合 `wechat-collage-cover`

封面默认使用 `wechat-collage-cover`，而不是普通科技风封面。

#### 4.1 触发规则

只要进入完整公众号流程，就自动生成拼贴封面，除非用户明确说“不生成封面”。

#### 4.2 封面视觉方向

使用高级编辑拼贴风：

- 手撕纸、旧报纸、胶带、便签、票据、扫描纹理；
- 视觉杂志感 / 独立 zine / 街头海报；
- 强标题层级；
- 一个明确视觉中心；
- 1-3 个主题隐喻物；
- 禁止廉价赛博朋克、机器人脸、PPT模板、电商 banner。

#### 4.3 封面尺寸

默认目标：

```text
900×383 px
```

同时建议归档：

```text
cover-collage-xxx-4k-master.jpg
```

如果当前 `image_generate` 只支持 coarse aspect ratio：

- 用 `landscape` 生成；
- 再本地裁切/适配到 900×383；
- 保证标题和视觉中心在安全区。

#### 4.4 封面 Prompt 文件

生成前必须保存：

```text
prompts/01-cover-collage-<topic>.md
```

Prompt 必须包含：

```text
Create a premium editorial torn-paper collage poster for a WeChat Official Account cover.
Target final cover size: 900×383 px, ultra-wide WeChat cover composition.
Theme / full title: "..."
Subtitle: "..."
Language: Chinese + concise English editorial microcopy.
A-layer giant visual text: "..."
B-layer complete title: "..."
Visual metaphor: ...
Style: hand-torn paper collage, vintage print grain, mixed media, magazine cover.
Strict: no typo, no logo, no watermark, no cheap cyberpunk, no ecommerce banner.
```

#### 4.5 中文标题质量策略

拼贴封面默认必须让 `wechat-collage-cover` / `image_generate` **直接生成封面文字、标题层级、拼贴视觉和完整构图**，不要默认拆成“AI 背景 + 本地代码叠字”。用户明确纠正过：公众号封面既然有专门封面 skill，就应优先得到一张原生拼贴字体封面，而不是准确但像代码生成的本地字体。

生成后必须 QA：

- 标题是否可读；
- 中文是否错字/乱码/伪字；
- 是否被裁切；
- 是否出现 logo、水印、无关英文大段文字；
- 是否存在明显“后期代码叠字 / 本地字体贴片”痕迹。

如果标题错字或不可读：

1. 优先继续使用 `wechat-collage-cover` 重生，缩短 A-layer 主视觉文字、减少微文案、强化 `No typos / readable Chinese title`；
2. 如果完整长标题容易错字，可把 A-layer 缩成 2-6 个字，把完整标题放到 B-layer 短纸条，或改成更短的封面标题；
3. 不要为了“字绝对正确”擅自上本地 CJK 字体叠字并直接上传；这种封面会被用户视为“代码生成字体”，不是期望的封面 skill 输出；
4. **只有用户明确同意“本地字体修复/兜底叠字”**，或用户要求精确文字优先于原生拼贴字体时，才允许本地叠字兜底，并在回复里明确说明这是修复兜底；
5. 最终上传版必须在“文字正确”和“封面字体自然”之间做 QA，优先交付原生拼贴感。

---

### 5. 正文信息图：用户偏好默认路径

正文插图默认使用 `wechat-baoyu-infographic-illustrations` + `baoyu-infographic`，不要用普通卡通插画替代。

固定规格：

```text
layout: dense-modules
style: craft-handmade
output: raster image
final target: 1080×608
archive master: 4K quality
```

推荐 3 张起步，复杂文章可 4 张：

| 图 | 用途 |
|---|---|
| 01 总览图 | 一眼看懂事件/概念边界 |
| 02 冲突图 | 展示矛盾、争议、利益关系 |
| 03 影响图 | 普通人/行业/企业会受什么影响 |
| 04 行动图 | 怎么办、路线图、选择建议 |

Prompt 原则：

- 1 个标题 + 1 个副标题 + 4-6 个模块；
- 中文短而准；
- 不要 logo、水印、假 UI、代码流；
- `FULL-BLEED content, no blank side margins`；
- 不用本地 PIL/SVG/HTML 画图冒充 baoyu 信息图；
- 如果中文乱码，重生，不要本地覆盖正文信息图文字。

---

### 6. 图片后处理与 QA

允许的本地处理：

- 裁切 / contain / resize；
- 生成 4K master；
- JPEG 压缩；
- 封面必要时本地准确叠加中文标题。

不允许：

- 用本地图形假装 raster backend 生成；
- 覆盖旧文件名；
- 正文图用 4K master 上传；
- 正文信息图错字后用本地文字覆盖修。

程序验证：

```bash
python3 - <<'PY'
from PIL import Image
for p in paths:
    print(p, Image.open(p).size)
PY
```

目标：

- 封面上传版：900×383（或上传脚本要求的封面尺寸，但文件名和 QA 要明确）；
- 正文图：1080×608；
- 4K master：同构图归档，不上传正文。

---

### 7. Markdown 图片引用审计

文章正文只引用正文信息图，不要把封面图插入正文。

检查：

```regex
!\[[^\]]*\]\(([^)]+)\)
```

成功标准：

- 所有正文图片 basename 包含 `real-baoyu-infographic`；
- 没有 `cover` 作为正文图片；
- 没有旧的 `illustration-*`；
- 新版本图片使用新 basename。

---

### 8. 微信渲染预检

使用 `md-to-wechat.ts`，不要用普通 `md-to-html.ts` 冒充微信预检。

```bash
bun /home/lighthouse/.hermes/profiles/gzhao-agent/skills/baoyu-skills/baoyu-social-publishing/scripts/md-to-wechat.ts article.md \
  --theme grace \
  --color orange \
  > logs/render-v1-result.json \
  2> logs/render-v1-stderr.log
```

检查：

- `contentImages` 数量正确；
- `contentImages` 指向最新图片 basename；
- `undefined: false`；
- `NaN: false`；
- `WBIMGPH_: false`。

---

### 9. 微信凭据处理

不要用 `write_file` 创建含 `WECHAT_APP_SECRET` 的 `.env`，Hermes 会脱敏/截断敏感值。

正确做法：

1. 复用已有可信 `.baoyu-skills/.env`；
2. shell `cp` 到当前草稿目录；
3. `chmod 600 .baoyu-skills/.env`；
4. 上传命令中 `set -a; . ./.baoyu-skills/.env; set +a` 注入环境变量；
5. 不打印 secret、access_token、完整 `.env`。

可信查找路径：

```text
/home/lighthouse/.hermes/profiles/gzhao-agent/workspace/.baoyu-skills/.env
/home/lighthouse/.hermes/profiles/gzhao-agent/workspace/*/.baoyu-skills/.env
/home/lighthouse/.hermes/profiles/gzhao-agent/home/wechat-drafts/*/.baoyu-skills/.env
```

预检必须显示：

```text
✅ API credentials: Found in .../.baoyu-skills/.env
```

---

### 10. 上传草稿箱

上传必须用 Markdown 原文调用 `wechat-api.ts`，不要上传预转 HTML。

**优先策略：frontmatter 完整时，尽量让脚本从 Markdown frontmatter 读取 `title` / `summary` / `author`，上传命令只传 `--cover`、主题和颜色。** 这样可以减少无人值守 cron 中长中文 CLI 参数触发 shell/安全审批/Unicode confusable 扫描的概率，也避免临时把作者改成 `jk` 之类的错误值。只有 frontmatter 缺失或需要覆盖时，才显式传 `--title` / `--summary` / `--author`。

推荐命令：

```bash
bun /home/lighthouse/.hermes/profiles/gzhao-agent/skills/baoyu-skills/baoyu-social-publishing/scripts/wechat-api.ts article.md \
  --theme grace \
  --color orange \
  --cover imgs/cover-collage-xxx.jpg \
  --no-cite \
  > logs/upload-v1.stdout \
  2> logs/upload-v1.stderr
```

如果必须覆盖元数据，再使用显式参数：

```bash
bun /home/lighthouse/.hermes/profiles/gzhao-agent/skills/baoyu-skills/baoyu-social-publishing/scripts/wechat-api.ts article.md \
  --theme grace \
  --color orange \
  --title "标题" \
  --summary "摘要" \
  --author "jk铭点" \
  --cover imgs/cover-collage-xxx.jpg \
  --no-cite \
  > logs/upload-v1.stdout \
  2> logs/upload-v1.stderr
```

再合并日志：

```bash
cat logs/upload-v1.stdout logs/upload-v1.stderr > logs/upload-v1.combined.log
```

成功标准：

```json
{
  "success": true,
  "media_id": "...",
  "title": "...",
  "articleType": "news",
  "method": "api"
}
```

stderr 中通常可见封面 `media_id`，但不要打印 token。

---

## Reference Notes

- `references/complete-all-continuation-checklist.md` — continuation checklist when an article is partially complete and the user asks to finish everything.
- `references/successful-ai-gated-access-draft-pattern.md` — compact proven pattern for AI policy/access-control hot topics such as GPT-5.6 / Mythos gated rollout: framing, fact boundaries, infographic prompt simplification, cover-skill-first cover QA, and upload audit.
- `references/gpt56-model-tiering-source-boundary-20260708.md` — session-specific GPT-5.6 / OpenAI model-tiering source boundary: accessible The Verge claims, HN Algolia metadata fallback for blocked Axios/Reuters/FT links, safe wording, article structure, visual package, and upload audit.
- `references/product-line-ai-model-launch-pattern.md` — proven pattern for user-provided model-family positioning such as Sol / Terra / Luna: frame as AI product-tiering, keep fact boundaries, and use a 4-card infographic stack.
- `references/efficient-agent-model-launch-pattern.md` — proven pattern for Claude Sonnet 5-style model launches framed as “高能低耗” / cost-performance Agent upgrades: conservative fact boundaries, beginner-friendly article structure, cover metaphor, and 3-card baoyu-infographic stack.
- `references/daily-china-ai-topic-scan-pattern.md` — daily Chinese AI topic-scan pattern for GLM-5.2 / 豆包 / Seedance / 火山引擎 FORCE style requests: stop at 5-6 candidates, use official docs plus Chinese tech-source signals, and wait for user confirmation.
- `references/beginner-codex-domestic-models-pattern.md` — proven WeChat pattern for beginner-friendly Codex / Claude Code / Cursor topics using GLM, DeepSeek, Kimi, and MiniMax as a multi-model “AI小团队”: framing, title bank, article structure, cover metaphor, and baoyu-infographic stack.
- `references/workbuddy-beginner-office-loop-pattern.md` — proven WeChat pattern for WorkBuddy beginner office-loop topics: copy-paste command packs, Ask → Plan → Craft practical story framing, WorkBuddy vs Claude Code/Codex positioning, safety rules, and visual package prompts.
- `references/ai-social-entry-doubao-wechat-pattern.md` — proven WeChat pattern for AI social-entry topics such as 豆包 vs 微信 / 飞书 / 企业微信 / 小程序 Agent: fact boundaries, title shapes, article angle stack, and visual pitfalls.
- `references/life-app-ai-assistant-beginner-pattern.md` — proven WeChat pattern for AI entering mass-market life apps such as 支付宝阿宝 / 高德 / 滴滴 / 美团 Agent: beginner-friendly framing, conservative fact boundaries, safety emphasis, cover metaphor, and 3-card baoyu-infographic stack.
- `references/ai-agent-shutdown-data-portability-pattern.md` — proven WeChat pattern for AI 智能体/Agent 功能下线、平台迁移、AI资产备份、数据可携带性 topics such as 豆包/千问智能体下线: fact boundaries, article structure, cover metaphor, and 3-card baoyu-infographic stack.
- `references/deepseek-paid-era-pattern.md` — proven WeChat pattern for DeepSeek收费 / 国产AI免费时代结束 / AI水电费时代 topics: fact boundaries, article structure, cover metaphor, and 3-card baoyu-infographic stack.
- `references/workbuddy-beginner-prompt-template-pattern.md` — proven WeChat pattern for WorkBuddy 新手指令/提示词 articles: beginner framing, verified fact boundary, 10 copyable office-command buckets, collage cover metaphor, and 3-card baoyu-infographic stack.
- `references/wechat-ai-miniapp-token-support-pattern.md` — proven WeChat pattern for AI 小程序平台扶持 / Token 额度 / 普通开发者红利 topics: conservative fact boundaries when evidence is snippet-level, “Token=模型水电费” beginner framing, narrow-scenario product advice, cover metaphor, and 3-card baoyu-infographic stack.
- `references/approval-safe-upload-continuation.md` — approval-safe continuation pattern when a full article/visual pack is complete but credential copy, render preflight, or WeChat upload is interrupted by an authorization gate. Split upload-phase commands and resume without regenerating assets.

## Continuation Workflows

### 用户说“继续执行，完成全部”

当上一篇已经完成选题/正文/提示词，但还没有生成视觉资产或上传草稿箱时，不要重新展开长篇计划，也不要再次确认上传；按 `references/complete-all-continuation-checklist.md` 继续完成剩余链路：生成封面和正文信息图、导出精确尺寸、复制可信 `.env`、微信渲染预检、API 上传、写 `upload-result.md`，最后只回复最新草稿 `media_id`、封面 `media_id`、预检摘要和必要的 `MEDIA:` 预览。

### 上传阶段被授权门中断

如果文章、封面、正文信息图、QA 和日志都已完成，但复制微信凭据、运行 `md-to-wechat.ts` 或 `wechat-api.ts` 时遇到授权等待/审批阻断，不要把它写成“工具不可用”，也不要重写文章或重生图片。按 `references/approval-safe-upload-continuation.md` 处理：把上传阶段拆成小命令，清楚说明“尚未上传草稿箱”，给出 ready asset 路径和最短继续口令（如“继续上传”），用户确认后从第一个未执行的预检/上传步骤继续。

### 每日定时选题任务

如果用户要求创建或修改“每天下午/每天固定时间执行公众号写作工作流”这类定时任务，并且没有明确要求无人值守直接成稿上传，默认任务只执行 **热点采集 + 5-6 个候选选题推荐**：

1. 聚焦当天 AI/科技热点，先运行 `date` 确认日期；
2. 至少交叉参考 3 个实时来源；
3. 输出 5-6 个候选选题，每个包含选题理由、热度/来源依据、目标读者、传播钩子、3-5 个备选标题、推荐指数；
4. 明确提示用户回复编号/标题确认；
5. **不要在定时任务里自行挑一个话题直接成稿、生成图片或上传草稿箱**，除非用户明确说“无人值守每天自动成稿/自动上传”。

用户确认某个编号后，才进入完整流程：写正文 → 生成拼贴封面 → 生成 baoyu 信息图 → 微信预检 → 凭据可用时上传草稿箱。确认后的同一工作流中不再重复询问上传确认。

---

## Revision Workflows

### A. 只改封面

用户说“封面不好 / 换成拼贴风 / 重新做封面”：

1. 不重写正文；
2. 用 `wechat-collage-cover` 生成新封面；
3. 新文件名：`cover-collage-v2-...jpg`；
4. 必要时只更新 frontmatter cover；
5. 重新 `md-to-wechat.ts` 预检；
6. 直接上传新草稿；
7. 回复最新草稿 `media_id` 和新封面 `media_id`。

### B. 只改某张正文图

用户说“第一张两侧留白 / 第二张错字 / 插图重生成”：

1. 只重生指定图片；
2. 新文件名：`inline-v2-XX-real-baoyu-infographic-...jpg`；
3. patch 出 `article-v2.md`；
4. 检查正文图片引用；
5. 预检；
6. 上传新草稿。

### C. 改文章结构

用户说“不够通俗 / 太短 / 太技术 / 重写”：

1. 保留事实来源与视觉资产；
2. 新建 `article-v2.md`；
3. 重点改开头、过渡、普通人影响、结尾互动；
4. 不重复生成图片，除非内容结构变化导致图不匹配；
5. 预检并上传新版。

---

## Reporting Format

最终回复要短，不重复长文。

```markdown
已完成并上传新版草稿。

## 最新草稿箱 media_id

```text
...
```

## 封面 media_id

```text
...
```

## 本次产出

- 文章：article.md
- 封面：wechat-collage-cover 拼贴风，900×383
- 正文插图：3 张，baoyu-infographic / craft-handmade / dense-modules，1080×608
- 上传方式：WeChat API

## 预检结果

```text
contentImages: 3
undefined: false
NaN: false
WBIMGPH_: false
upload: success
```

请以这个最新 media_id 对应的草稿为准，旧草稿可能仍在草稿箱里。
```

如果上传失败，必须明确说“尚未上传”，并给出 blocker、文件路径、日志路径。

---

## Common Pitfalls

1. **封面没有走 `wechat-collage-cover`。** 完整流程默认封面是高级拼贴风，不要退回普通科技风，除非用户指定。

2. **用本地代码字体冒充拼贴封面字体。** 用户明确不接受“看起来像代码生成/后期叠字”的公众号封面。封面 skill 默认应交付原生模型拼贴字体；中文错字优先重生和简化标题。只有用户明确同意本地字体修复时，才可作为兜底，并必须说明。

3. **拼贴封面中文错字还上传。** 封面可以有模型文字，但必须 QA；错字优先重生或缩短文案，不要擅自用本地字体叠字上传。

3. **正文图不是信息图。** 用户偏好正文插图为 baoyu 信息图，不要用普通卡通故事图替代。

4. **用本地绘图冒充 baoyu 信息图。** 不允许。正文信息图必须来自 raster image backend，本地只做尺寸/压缩/裁切。

5. **用 `write_file` 写 APP_SECRET。** 会触发脱敏/截断。只能复制可信 `.env` 或使用安全配置。

6. **上传成功没有 `media_id`。** 只有 `wechat-api.ts` 返回 `success: true` 和草稿 `media_id` 才算成功。

7. **复用旧图片名。** 微信缓存容易混淆。每次替换封面/插图都用新 basename。

8. **被阻断来源硬编。** 权威来源被反爬时只能用可验证元数据和其他来源交叉验证，不能编造细节。

9. **未给选题就直接成稿。** 用户只说“写一篇公众号爆款 / 测试写一遍”时，先给 5-6 个候选选题并等待用户选择；不要擅自选一个话题直接写全文。用户已明确指定选题时才跳过选择。

10. **正文里混入封面图。** 封面只作为 `--cover` 或 frontmatter cover，不作为正文图片。

11. **正文使用 Markdown 表格。** 公众号正文移动端表格体验差。结构化对比、问题/影响/方案、时间线等内容应改成短段落/项目符号，或生成 `real-baoyu-infographic` 信息图来表达。

12. **上传 4K master 到正文。** 正文图必须是 1080×608，4K master 只归档。

10. **正文使用 Markdown 表格。** 公众号正文移动端表格体验差。结构化对比、问题/影响/方案、时间线等内容应改成短段落/项目符号，或生成 `real-baoyu-infographic` 信息图来表达。

11. **上传 4K master 到正文。** 正文图必须是 1080×608，4K master 只归档。

---

## Verification Checklist

- [ ] 已判定任务模式：选题 / 已指定选题 / 已有文章 / 改封面 / 改插图
- [ ] 如果用户未指定具体选题，已先输出 5-6 个候选选题并等待用户选择；未擅自直接成稿
- [ ] 如涉及“今天/最新”，已运行 `date` 并采集至少 3 个来源
- [ ] 事实来源和热度信号保存到 `logs/research-sources.md`
- [ ] 文章 frontmatter 完整：title/author/summary/cover/original/comments
- [ ] 作者为 `jk铭点`
- [ ] 封面 prompt 已保存到 `prompts/01-cover-collage-*.md`
- [ ] 封面使用 `wechat-collage-cover` 视觉规范
- [ ] 封面上传版已生成，标题/文字 QA 通过
- [ ] 正文信息图 prompt 已保存
- [ ] 正文信息图为 `dense-modules + craft-handmade`
- [ ] 正文信息图上传版尺寸为 1080×608
- [ ] 4K master 已归档且未作为正文图上传
- [ ] Markdown 正文图片均为 `real-baoyu-infographic`，无封面混入正文
- [ ] 正文没有 Markdown 表格；结构化内容已改为短段落/项目符号或正文信息图
- [ ] `.baoyu-skills/.env` 通过复制复用，未用 `write_file` 写 secret
- [ ] `check-permissions.ts` 显示 API credentials found
- [ ] `md-to-wechat.ts` 预检无 `undefined`、`NaN`、`WBIMGPH_`
- [ ] `contentImages` 数量和文件名正确
- [ ] `wechat-api.ts` 返回 `success: true` 和草稿 `media_id`
- [ ] 上传日志已保存到 `logs/`
- [ ] 回复用户最新草稿 `media_id`、封面 `media_id`、产出路径和预检结果
