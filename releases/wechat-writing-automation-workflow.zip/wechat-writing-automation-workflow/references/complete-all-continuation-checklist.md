# Complete-All Continuation Checklist

Use this reference when the user first picked a topic and the previous turn produced `article.md` plus prompt files, then says “继续执行，完成全部”.

## Goal

Finish the remaining WeChat workflow without re-asking: generate cover and inline images, post-process dimensions, render-preflight, copy trusted WeChat credentials, upload to the draft box, and report only the latest handles.

## Sequence

1. Load/confirm the visual and publishing subskills already in the stack:
   - `wechat-collage-cover`
   - `wechat-baoyu-infographic-illustrations`
   - `baoyu-infographic`
   - `baoyu-social-publishing`
2. Generate the cover and all planned inline images from the saved prompt files.
3. Preserve raw generated images under `imgs/` with `*-raw` names before any crop/resize.
4. Export final upload assets:
   - Cover: `cover-collage-<topic>-<date>.jpg`, `900×383`.
   - Cover archive: `cover-collage-<topic>-<date>-4k-master.jpg` or same-ratio large master.
   - Inline body images: `inline-vN-XX-real-baoyu-infographic-<topic>-<date>.jpg`, exactly `1080×608`.
   - Inline archives: same basename with `-4k-master.jpg`, e.g. `4320×2432`.
5. Programmatically print dimensions for every generated image and verify article Markdown references exist.
6. Copy a trusted existing `.baoyu-skills/.env` into the draft directory, `chmod 600`, and never print secrets.
7. Run `md-to-wechat.ts article.md --theme grace --color orange` and save:
   - `logs/render-vN-result.json`
   - `logs/render-vN-stderr.log`
8. Verify render output explicitly:
   - `contentImages` count matches inline images.
   - `undefined: false`
   - `NaN: false`
   - `WBIMGPH_: false`
   - `contentImages` point to the latest `real-baoyu-infographic` basenames.
9. Run `check-permissions.ts` after loading copied credentials and save `logs/check-permissions.log`; report only the API credential source status, not values.
10. Upload with `wechat-api.ts` using the Markdown file, not pre-rendered HTML. Save:
    - `logs/upload-vN.stdout`
    - `logs/upload-vN.stderr`
    - `logs/upload-vN.combined.log`
11. Write `upload-result.md` with draft `media_id`, cover `media_id`, title, author, image paths, and preflight summary.
12. Final reply should be concise and non-duplicative: latest draft `media_id`, cover `media_id`, what was produced, preflight result, workdir, and optionally one cover `MEDIA:` preview.

## Notes

- If image generation returns a non-16:9 landscape bitmap, save raw first, then export exact final sizes. For text-heavy inline infographics, avoid aggressive cropping unless the layout remains safe; prefer preserving text clarity over perfect edge fill.
- Keep filename uniqueness. Do not overwrite old draft images when replacing or continuing a draft workflow.
- If upload fails, say “尚未上传” and provide blocker plus ready-to-upload paths/logs; never imply a draft exists without `success: true` and a draft `media_id`.