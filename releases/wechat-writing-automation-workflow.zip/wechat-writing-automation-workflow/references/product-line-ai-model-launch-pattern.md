# Product-Line AI Model Launch Pattern

Use this reference when a user provides product positioning for a model family (for example `Sol / Terra / Luna`) and asks to run the WeChat writing automation workflow.

## Framing that worked

Turn a model-family release into a public-readable business/usage story:

- Do not write it as a benchmark-only technical update.
- Frame it as “AI enters product-tier / shelf era”: flagship, mainline, value tier.
- Explain why tiering matters to ordinary users: capability access, cost, workflow choices, and hidden productivity gaps.

## Example structure

1. Hook: “不是 GPT-5.6 变强了，而是 AI 被做成了三档货架。”
2. 先说结论：AI 进入“机型时代 / 分层供应时代”。
3. Sol: flagship / frontier capability; explain as complex-task engine, not just “smarter chat”.
4. Terra: close to previous flagship but cheaper; focus on enterprise adoption, high-frequency calls, product depth, price pressure.
5. Luna: value model; explain why “cheap, stable, enough” is often the true mass-market entry.
6. New order: flagship shows capability, mainline carries production, value tier drives popularization.
7. Practical advice: don’t blindly chase flagship; maintain a model ledger, route tasks by difficulty/cost, turn prompts into workflows, watch open-source/domestic alternatives.
8. Comment hook: ask which tier the reader would choose and why.

## Fact-boundary rule

When product claims are user-provided, label them internally as user-provided basis and do not invent:

- exact benchmark numbers;
- exact pricing;
- internal rollout rules;
- access-policy mechanics;
- model capabilities beyond the positioning supplied.

## Visual stack

Recommended assets:

- Cover: `wechat-collage-cover` complete generated cover; A-layer can be `AI分层`; B-layer complete title; visual metaphor = three shelves/cards for Sol / Terra / Luna.
- Inline 01: 三档模型 — Sol旗舰 / Terra主力 / Luna普及.
- Inline 02: 成本减半 — enterprise adoption and product-depth impact.
- Inline 03: AI货架 — flagship/mainline/value + task routing/model ledger/workflow.
- Inline 04: 四个动作 — ordinary-user action plan.

Keep inline infographic labels short and exact; regenerate raster images if Chinese text is wrong. Do not use local text overlays for正文信息图.
