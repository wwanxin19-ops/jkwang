# WorkBuddy beginner prompt-template article pattern

Use this reference when the user asks for a beginner-friendly WeChat article about Tencent WorkBuddy, AI office agents, or “新手指令/提示词直接复制”.

## Proven angle

Best-performing framing for小白 readers:

- Don’t explain Agent/MCP/model details first.
- Start from the reader’s real blocker: “不是不会用 AI，而是不知道第一句话怎么说。”
- Treat WorkBuddy as an “AI 工作搭子 / 会执行的办公助手”, not as a technical product review.
- The core promise is practical: copy 10 commands, replace variables, get a usable work output.

## Fact boundary

Safe verified product facts from the official WorkBuddy page (`https://copilot.tencent.com/work/`):

- WorkBuddy positions itself as an AI workbench / AI Agent office workflow.
- Official copy emphasizes “一人指挥，全行业专家执行”, “免部署·安装即用”, “多专家·多模型协同”, and desktop / mainstream IM / mini-program access.
- Official scenario buckets include external research and content generation, business data insight and automated response, and multi-role office workflows.
- Official examples include industry/competitor research, generating PPT from topics/templates, analyzing user feedback/comments, and producing insight reports.

Avoid unverifiable claims such as exact time saved, exact benchmark performance, or unsupported integration details unless a live source is checked in the current session.

## Recommended article structure

1. Hook: “很多人不是不会用 AI，而是不知道第一句话该怎么说。”
2. Explain the beginner mistake: prompts are too broad, e.g. “帮我提高工作效率”.
3. Give the practical rule: task + background + output format + audience.
4. Provide 10 copyable commands.
5. Insert 3 baoyu-infographic cards:
   - Card 1: WorkBuddy 新手上手 / 先从小任务开始 / six low-risk tasks.
   - Card 2: 10 条复制指令 / 从整理到交付 / six command categories.
   - Card 3: 从指令到成果 / 新手三步法 / say task, add context, specify format, draft, human check, optimize.
6. End with the principle: AI does the first draft; humans verify facts, judgment, and tone.
7. Interaction question: ask which small task the reader wants WorkBuddy to solve first.

## The 10 command buckets

Use short, copyable, variable-based prompts. Good buckets:

1. Meeting notes → conclusions, todos, owner, deadline.
2. Fragmented work records → weekly report.
3. Casual wording → leadership report tone.
4. Topic → 8-page PPT outline.
5. Product A vs B → beginner-readable competitor analysis.
6. Long document → one-page summary.
7. Customer feedback → problem categories and top issues.
8. Idea → 7-day execution plan.
9. Vague task → ask me 5 clarifying questions first.
10. Existing output → self-check for empty words, missing actions, unverified claims, beginner usability.

## Visual pattern

Cover:

- Use `wechat-collage-cover` with A-layer text like `照抄就能用` and B-layer like `WorkBuddy 新手指令大全`.
- Premium torn-paper collage, prompt cards, sticky notes, laptop workspace, checklist, PPT/weekly report/meeting note elements.
- No real Tencent/WorkBuddy logo.

Inline graphics:

- Use `real-baoyu-infographic` raster generation, `dense-modules + craft-handmade`.
- Keep on-image Chinese short and exact.
- Export 1080×608 upload images and 4K masters.

## Upload/preflight notes

- Use frontmatter title/author/summary/cover; author should remain `jk铭点` unless user says otherwise.
- No Markdown tables in body; use prose and infographic cards instead.
- Run `md-to-wechat.ts` and verify: `contentImages` count, no `undefined`, no `NaN`, no `WBIMGPH_`.
- If credentials are available, upload directly with `wechat-api.ts` and report both draft `media_id` and cover `media_id`.
