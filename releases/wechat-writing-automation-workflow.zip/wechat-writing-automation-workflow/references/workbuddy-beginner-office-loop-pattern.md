# WorkBuddy beginner office-loop WeChat pattern

Use this reference when the user asks for WeChat Official Account content about WorkBuddy, especially beginner-friendly AI-office workflows, prompt packs, or practical office-loop stories.

## Source shape that worked

Two useful WorkBuddy article angles emerged:

1. **Prompt pack / template angle**
   - Example title: `WorkBuddy 新手指令大全：这 10 句话直接复制就能用`
   - Best for: high 收藏率, beginner onboarding, copy-paste utility.
   - Core promise: readers can start with weekly reports, meeting notes, PPT outlines, competitor analysis, document summaries, customer feedback, 7-day plans, reverse questioning, and output self-checking.

2. **Practical loop / story angle**
   - Example title: `我用 WorkBuddy 跑通第一条 AI 办公闭环后，才明白新手最该学的不是提示词`
   - Best for: stronger narrative and trust, turning an X/article/user-supplied experience into a WeChat story.
   - Core promise: WorkBuddy is not just a chat box; the real beginner skill is turning work into an executable loop.

## Beginner-friendly framing

Avoid starting with hard concepts such as Agent, MCP, connectors, skills, expert groups, or multi-model orchestration. Start from the reader’s immediate pain:

- 不知道第一句话怎么说
- 周报 / 会议纪要 / PPT / 竞品分析很耗时
- AI 给建议但人还要自己复制粘贴
- 怕 AI 乱改文件 / 乱发内容

Then explain WorkBuddy as an **AI 工作搭子 / AI 办公工作台** that can read materials, plan steps, generate files, and support delivery.

## Core workflow to teach

For WorkBuddy practical pieces, repeatedly emphasize:

```text
Ask 先看清楚 → Plan 确认方向 → Craft 再执行 → 人工验收
```

Write the four steps in plain language:

- **Ask**: 先让它列出看到了哪些文件、每个文件是什么内容、准备基于哪些材料工作。
- **Plan**: 先给执行方案，检查是否会改原始文件、读错目录、编造数据、触发外部动作。
- **Craft**: 确认后再生成周报、PPT、网页、表格或待办。
- **Check**: 不相信“完成了”三个字，自己打开文件验收数字、路径、格式、链接和页面效果。

## Recommended article structures

### A. Copy-paste command pack

1. Opening: many people are not bad at AI; they just do not know the first sentence to type.
2. Conclusion: beginner prompts need task + context + output format.
3. 10 commands, each with:
   - copyable command in bold
   -适合场景
   - why this wording works
4. Three formulas:
   - 任务 + 背景 + 输出格式
   - AI 做初稿，人做判断
   - 从小任务开始
5. CTA: ask which office task they want to try first.

### B. Practical loop story

1. Opening: after running one complete WorkBuddy loop, the lesson is not “better prompts” but “executable workflow”.
2. WorkBuddy vs normal chat AI: not chatting, but delivering.
3. WorkBuddy vs Claude Code / Codex: WorkBuddy for non-coders and office/Tencent ecosystem; Claude Code/Codex for heavy code tasks.
4. Ask → Plan → Craft explanation.
5. Two examples:
   - Excel → weekly report → PPT
   - product materials → landing page prototype
6. Four concepts explained simply: model, expert, expert group, skill.
7. Safety: connector + workspace boundaries.
8. Six rules for beginners.
9. Ending: AI office is not “asking beautifully” but “delivering reliably”.

## Safety rules to include

WorkBuddy beginner pieces should include the six practical rules because they reduce overtrust and make the article more credible:

1. 一个任务一个文件夹。
2. 重要任务必须先 Plan。
3. 默认权限就够用，敏感操作每次确认。
4. 技能只开必要的。
5. 对外发送 / 删除 / 覆盖 / 发布前，先让它列出对象和内容。
6. 它说完成，不等于真的完成；必须人工打开文件验收。

## Visual package pattern

Use the standard WeChat workflow visuals:

- Cover: `wechat-collage-cover`, premium torn-paper collage. Good A-layer phrases:
  - `照抄就能用`
  - `办公闭环`
  - `AI工作搭子`
- Inline images: real `baoyu-infographic`, `craft-handmade + dense-modules`, final `1080×608`, 4K master archived.
- Good inline image themes:
  - `WorkBuddy 新手上手`: 会议纪要 / 周报初稿 / PPT大纲 / 竞品分析 / 文档摘要 / 输出自检
  - `Ask Plan Craft`: Ask 看清文件 / Plan 审查方案 / Craft 执行交付 / Check 人工验收
  - `新手安全边界`: 单独文件夹 / 重要先 Plan / 权限别太大 / 技能少而准 / 对外先确认 / 完成要验收

## Upload / preflight notes

The normal workflow worked well:

- Create a dedicated directory under `home/wechat-drafts/<slug>-YYYYMMDD/`.
- Save `article.md`, `draft-metadata.md`, prompt files, `logs/research-sources.md`.
- Copy trusted `.baoyu-skills/.env` from the workspace; do not print secrets.
- Run `md-to-wechat.ts article.md --theme grace --color orange`.
- Verify:
  - `contentImages` equals the inline infographic count.
  - `undefined: false`
  - `NaN: false`
  - `WBIMGPH_: false`
  - no Markdown tables
  - no cover image referenced in article body
- Upload with `wechat-api.ts article.md --theme grace --color orange --cover imgs/cover-collage-*.jpg --no-cite`.

## Pitfalls

- Do not make the piece a generic WorkBuddy feature list. Anchor it in a real work task.
- Do not over-explain technical architecture in the first screen. Put concepts after the reader already understands the office scenario.
- Do not present WorkBuddy as replacing Claude Code/Codex. Frame it as different scenarios: office/Tencent/non-coder vs heavy development.
- Do not skip safety. Beginner readers need workflow boundaries, not just excitement.
