# Successful Pattern: AI Gated-Access Hot Topic → WeChat Draft

Use this as a compact reference for future “今日 AI 热点 → 公众号草稿箱” runs when the selected topic is a policy/access/control story such as GPT-5.6 / Mythos gated rollout.

## What worked

- Topic framing: convert technical model-launch news into a broad public-interest conflict: “最强 AI 不再是谁都能用 / AI 进入闸门时代”.
- Provocative user titles: if the user provides a high-click headline such as “GPT5.6惨遭切脑！Fable 5回归要变弱鸡版？”, preserve it as the article title, but explicitly frame “切脑 / 弱鸡版” as a rhetorical metaphor in the body rather than a verified technical fact.
- Fact boundary: only use accessible headline-level claims and observed heat signals; do not invent paywalled details, benchmarks, internal policy mechanics, model degradations, or capability cuts. For gated-access stories, safe claims are “limited release / trusted partners / restricted access / no public timeline”; unsafe claims are “model was literally weakened / benchmark-cut / lobotomized” unless a source states that directly.
- Article structure: explain the rule change in plain language:
  1. 先说结论：AI 正在进入“闸门时代”
  2. 发生了什么：GPT-5.6 rollout restriction + Anthropic Mythos trusted-org access
  3. 为什么会爆：普通用户、创业公司、开发者三类焦虑
  4. 普通人要关心的是“权限差”
  5. 安全与公平的平衡
  6. 普通人怎么做：别只盯模型名，建立工作流，关注开源/国产模型
- Visual stack: collage cover + 3 inline baoyu-infographic cards.

## Inline infographic prompt adjustment

For Chinese baoyu-infographic cards, if a dense/long title produces awkward or questionable text, regenerate with:

- very short title: 2–5 Chinese characters, e.g. `AI闸门`, `规则变了`, `谁会受影响？`
- concise subtitle carrying the nuance
- exactly 6 short module labels
- “Keep Chinese text very large and exact”
- “No fake text, no extra labels”

This is better than trying to force a long headline into the generated image. Do **not** fix正文信息图 text by local overlays; regenerate the raster image with shorter labels.

## Cover pattern

Default cover behavior after user correction:

- Use `wechat-collage-cover` to generate the **complete** premium collage cover, including main title hierarchy and visual composition.
- Do not default to “no-readable-text background + local code title overlay”; that should only be a clearly disclosed repair fallback after repeated title-generation failures or explicit user request.
- For long titles, reduce the A-layer to a short 2–6 character phrase and put the complete title in B-layer paper-strip/news-headline text.
- QA the final 900×383 cover for title readability, no crop, no pseudo-text, no logo/watermark, and no obvious local-code-overlay look.

## Verification pattern

Before upload, keep the minimal audit:

```text
contentImages: 3
undefined: false
NaN: false
WBIMGPH_: false
all Markdown image refs contain real-baoyu-infographic basenames
cover is passed via --cover, not inserted in body
```

Upload success is only valid after `wechat-api.ts` returns `success: true` and a draft `media_id`; save a compact `upload-result.md` with draft media_id, cover media_id, paths, and preflight summary.
