# Life-App AI Assistant Beginner Pattern

Use this reference when a daily AI topic is about AI entering a mass-market life app, such as 支付宝阿宝、AI版支付宝、高德/滴滴/美团/生活服务 Agent, and the target article is for AI 新手小白.

## Best framing

Core angle:

> 普通人第一次真正用上 AI，可能不是在聊天框里，而是在每天都用的生活 App 里。

Do not frame the story as a technical model launch. Frame it as a product-entry shift:

- From “open a blank chatbot and think of a prompt”
- To “state a life task inside a familiar app”
- From “人找功能”
- To “AI 找入口 / 帮你把流程摆好”

This works especially well for beginner audiences because they do not need to learn model names, prompt formulas, or agent architecture before seeing practical value.

## Fact boundaries

For 支付宝阿宝-style topics, keep claims conservative:

- OK: official/open reports say users can search “阿宝/蚂蚁阿宝”, enter a new right-swipe experience, and arrange tasks through conversation.
- OK: examples like “查公积金” can be described as matching service mini-programs/entries and surfacing the operation page.
- Must state: transactions, fund movement, payment, authorization, and final confirmation remain with the user.
- Avoid: implying the AI can autonomously pay, transfer money, or complete sensitive operations without user confirmation.
- Avoid: real platform logos in generated visuals unless explicitly provided/authorized; use generic service cards, payment-neutral icons, and abstract life-app UI.

## Article structure that performed well

Suggested title shapes:

- AI版支付宝来了：普通人第一次真正用上AI，可能不是在聊天框里
- 支付宝开始变AI助手，普通人该怎么用？
- 以后不会用App没关系，AI可能直接帮你找入口
- 从聊天到办事，AI终于走进普通人的生活

Recommended outline:

1. Open with the “blank chatbot problem”: many people have heard of AI, but do not know what to ask.
2. Introduce the life-app event with verified facts.
3. Key conclusion: the beginner-friendly AI entry may be inside familiar apps, not standalone chatbots.
4. Explain “陈列式 App → 对话式 App” with the supermarket/guide metaphor.
5. Explain why this is better for 小白: real tasks, familiar scenes, no prompt-learning burden.
6. Emphasize safety boundary: AI helps prepare/find/route; user confirms money-sensitive steps.
7. Give a three-step beginner playbook:
   - 把“我要点哪里”改成“我要办什么”
   - 把一句话说完整
   - 涉及钱的操作自己确认
8. Close with a debate prompt: convenience vs risk.

## Visual pattern

Cover:

- Use `wechat-collage-cover` premium torn-paper collage.
- Palette: warm orange/cream/black with small blue accent.
- A-layer short text works better than full long title: `AI办事`.
- B-layer: `AI版支付宝来了` or another short exact phrase.
- Visual metaphor: a generic mobile service interface turning into a friendly AI concierge; receipts, service cards, search box, city-life icons.
- Forbid real Alipay logo, QR code, and brand-specific UI screenshots.

Inline baoyu-infographic stack:

1. Overview: `AI版支付宝 / 从找功能到说需求`
   - 对话入口 / 服务匹配 / 少点几步 / 本人确认 / 生活办事
   - Bottom: `AI不是替你乱点，而是帮你找到路`
2. Beginner fit: `小白友好入口 / 不用学AI，先办小事`
   - 不背提示词 / 不懂模型也能用 / 直接说需求 / 场景很熟悉 / 从查找开始
3. Beginner playbook: `新手三步法 / 会说需求，就会用AI`
   - 说我要办什么 / 把一句话说完整 / 让AI先找入口 / 涉及钱自己确认 / 从小任务练起

Generation notes:

- Keep Chinese short and exact.
- `dense-modules + craft-handmade`, raster, full-bleed.
- Export正文图 to exactly 1080×608 and keep 4K masters separately.
- QA cropped final versions, not only the original generations.

## Upload/preflight reminders

- Save source facts to `logs/research-sources.md` with clear “what is verified” and “what not to overclaim”.
- Copy trusted `.baoyu-skills/.env` into the draft workdir and chmod 600; never rewrite secrets via `write_file`.
- Run `md-to-wechat.ts article.md --theme grace --color orange` before upload.
- Verify `contentImages` count and exact new basenames.
- Upload with `wechat-api.ts` using the Markdown file and separate `--cover` path.
