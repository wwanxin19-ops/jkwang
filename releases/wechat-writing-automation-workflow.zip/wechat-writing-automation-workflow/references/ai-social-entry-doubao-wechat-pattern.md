# AI 社交入口 / 豆包 vs 微信 选题成稿模式

Use when the user asks for WeChat Official Account writing around “豆包抢微信入口 / AI 社交入口大战 / 微信 AI Agent / 飞书 / 企业微信 / 小程序 Agent”.

## Fact boundary

Do not state “豆包已正式接入微信” unless a primary source confirms it. Safer framing:

- 豆包在社交能力、飞书账号、导航/生活场景上加速；
- 微信在 AI Agent、小程序服务调用、企业微信 Agent 上开放/内测；
- 双方都在争夺下一代 AI 社交和服务入口。

## Reliable angle stack

1. **入口变化**：从“打开 App 点功能”变成“对 AI 说一句话，AI 调服务”。
2. **豆包进攻**：从 AI 助手向工作流、生活服务、关系链靠近。
3. **微信防守反击**：关系链、小程序、支付、本地生活、企业微信是天然护城河。
4. **社交重定义**：AI 社交不是单纯陪聊，而是 AI 帮人处理真实关系和任务。
5. **普通人影响**：群聊总结、订餐出行、客户跟进、办公协作、内容生产。

## Proven title shapes

- 《豆包开始抢微信的入口了？AI 社交大战终于露头》
- 《豆包打通飞书，微信开放 Agent：AI 社交入口战打响了》
- 《微信不是在做 AI 聊天，而是在做 AI 操作系统》
- 《下一代社交 App，可能不是人聊人，而是 AI 帮人办事》

## Visual pitfalls from session

- For covers, keep Chinese title text short. “入口” is visually easy for image models to mangle into “人口”; prefer a short A-layer like `入口战` plus a short B-layer like `豆包抢入口 微信守生态`, then QA visually before upload.
- For inline infographics about platform ecosystems, forbid real brand logos. Use abstract rounded app tiles / generic service cards instead of recognizable WeChat、支付宝、抖音 logos.
- If generated Chinese or logos fail QA, regenerate with shorter labels and stricter constraints; do not locally overlay text on baoyu-infographic body images.

## Suggested infographic stack

1. **AI 社交入口战总览**：豆包、飞书、微信、小程序、企业微信、关键问题。
2. **双方手里的牌**：豆包/飞书/导航生活 vs 微信/小程序/企业微信。
3. **普通人会先感受到什么**：群聊总结、订餐出行、客户跟进、办公协作、内容生产、入口变化。
