# Pattern: Beginner Codex + Domestic Models → WeChat Draft

Use this pattern when the user asks for公众号选题/成稿 around GLM-5.2, DeepSeek, Kimi, MiniMax, and beginner-friendly Codex / Claude Code / Cursor AI coding workflows.

## Topic framing that worked

Frame the story for non-programmers as **“new手不是选最强模型，而是搭一个会分工的 AI 小团队”**.

Strong core angle:

- GLM: project lead / project manager — longer context, task splitting, project structure, end-to-end delivery.
- DeepSeek: cost-control assistant — cheap repeated trials, batch fixes, error explanations, low-risk iterations.
- Kimi: frontend / expression partner — pages, UX, components, copy, visual structure.
- MiniMax: data/materials assistant — PDFs, screenshots, long docs, meeting notes, multimodal/source-material cleanup.
- Codex / Claude Code / Cursor: the workbench where these roles connect into a coding workflow.

Best title pattern:

```text
GLM写项目，DeepSeek省钱，Kimi做前端，MiniMax管资料
```

Alternative titles:

- `新手用Codex的正确姿势：不是选模型，而是搭班子`
- `把国产大模型接进Codex后，普通人也能组一个虚拟开发团队`
- `GLM、DeepSeek、Kimi、MiniMax，谁最适合小白做AI编程？`

## Research signals to look for

Use live/current sources, but these durable signals are worth searching for:

- Bing/video results around `Codex 接入 DeepSeek MiniMax GLM Kimi 教程`.
- B站/YouTube tutorial signals such as “Codex 国内零门槛用上 DeepSeek”, “Codex接入DeepSeek, MiniMax, GLM等模型”.
- HN/GitHub signals around model routing in Claude/Codex/Cursor and AI coding-agent workflows.
- Articles comparing `GLM-5.2 vs Kimi 2.7 Code`, `DeepSeek Coder`, `MiniMax M3`.

Treat video view counts/search snippets as heat signals, not as hard technical proof.

## Article structure

Recommended article structure:

1. Hook: 新手用 Codex 不该纠结哪个模型最强，而是要会分工。
2. 先说结论: 把模型当不同员工，不是一个万能神。
3. 为什么新手更需要多模型: 降低试错压力，让每一步更可理解。
4. GLM: 项目主力，负责拆任务、搭结构、推进工程。
5. DeepSeek: 成本助理，负责低成本多轮试错。
6. Kimi: 前端搭子，负责页面、交互、表达优化。
7. MiniMax: 资料管家，负责文档、截图、素材输入。
8. 三步上手: 选小需求 → 拆任务分工 → 记录工作流模板。
9. 结尾互动: 你最想用 Codex 做哪类小工具？资料整理、网页生成、自动化脚本还是公众号工作流？

Avoid presenting untested setup commands as verified. If the workflow did not actually configure the models, write as a conceptual/selection guide rather than a hard tutorial.

## Visual stack

Use 3 inline baoyu-infographic cards:

1. **四个模型怎么分工？**
   - GLM 项目主力
   - DeepSeek 成本助理
   - Kimi 前端搭子
   - MiniMax 资料管家
   - Codex 工作台
   - 核心：不是选最强，而是会派活

2. **小白三步上手**
   - 选小需求
   - 整理资料
   - 设计结构
   - 做出页面
   - 反复修改
   - 留下模板

3. **虚拟开发团队**
   - 产品经理：你负责说清目标
   - 项目经理：GLM
   - 前端设计：Kimi
   - 执行助理：DeepSeek
   - 资料助理：MiniMax
   - 验收官：你

Visual style: `dense-modules + craft-handmade`, 1080×608 final, 4K master archive, warm craft paper, role cards, arrows, sticky notes, no fake UI/logos/watermarks.

## Cover pattern

Cover title can use the practical role-based headline. Use `wechat-collage-cover` with:

- A-layer: `搭班子`
- B-layer: full title
- Metaphor: beginner desk, four paper role cards, central Codex notebook/workbench, routing arrows, team org chart.
- Palette: orange/yellow + electric blue + cream paper; warm and lively, non-tech.

## Reporting

Keep final report short: draft media_id, cover media_id, article title, output path, preflight summary, and one cover preview. Do not repeat the full article.