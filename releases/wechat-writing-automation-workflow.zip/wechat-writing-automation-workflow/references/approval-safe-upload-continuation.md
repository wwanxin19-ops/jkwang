# Approval-safe WeChat upload continuation pattern

Use when a full WeChat article workflow has already produced `article.md`, cover, inline baoyu-infographics, prompt files, and QA logs, but the final preflight/upload command is interrupted by an approval gate, timeout, or user authorization wait.

## Durable lesson

Do not bundle credential copy, permission checks, render preflight, and `wechat-api.ts` upload into one large shell command near the end of a workflow. If an approval gate blocks the compound command, the whole upload phase becomes ambiguous and harder to resume.

## Safer sequence

1. Finish and save all durable assets first:
   - `article.md`
   - `draft-metadata.md`
   - `logs/research-sources.md`
   - `logs/visual-qa.md`
   - cover and inline image files at exact upload dimensions
2. If credentials are needed, copy the trusted `.env` in a small isolated command and do not print secrets.
3. Run `check-permissions.ts` as a separate preflight command; report only safe summary lines.
4. Run `md-to-wechat.ts` as a separate render command; inspect `contentImages`, `undefined`, `NaN`, and `WBIMGPH_`.
5. Only after preflight passes, run `wechat-api.ts` as the final side-effect command.
6. If any step is blocked by user approval, stop immediately and tell the user: assets are complete, not uploaded yet, and reply with the exact continuation trigger such as “继续上传”. Do not regenerate article or images on continuation unless the user asks for changes.

## Continuation reply shape

When blocked before upload, keep the user-facing reply compact:

- State clearly: `尚未上传草稿箱`.
- Give the blocker: `等待授权执行微信凭据/上传预检命令`.
- Give ready asset paths and one preview image.
- Ask for the minimal continuation phrase: `回复“继续上传”即可继续预检并上传`.

## Resume checklist

On continuation:

- Reuse the existing workdir.
- Re-read only `draft-metadata.md` / `article.md` if needed.
- Do not rewrite title/body/visual prompts.
- Continue from credential copy or render preflight, whichever was the first blocked step.
- Upload only after `md-to-wechat.ts` proves content image paths match the latest files.
