# Daily AI Topic Scan Pattern: GLM-5.2 / 豆包 / Seedance

Use this reference when the user asks for daily Chinese AI boom topics specifically around `GLM-5.2`, `豆包`, `Seedance`, `Seedream`, `火山引擎 FORCE`, or domestic model updates.

## Workflow lesson

- If the user asks for “选题可以选 5-6 个” or corrects that they want to confirm topics, stop at the topic-candidate stage.
- Do **not** auto-select one topic, write the full article, generate visuals, or upload.
- Ask the user to reply with a number/title before continuing the full WeChat workflow.

## Search/source pattern

1. Run `date '+%Y-%m-%d %H:%M:%S %Z'` first.
2. Use Chinese web/news search plus official docs/product pages where possible:
   - 智谱官方文档: `docs.bigmodel.cn` for GLM model capabilities.
   - 豆包官网/search snippets for current product-entry signals such as Seedance integration.
   - 火山引擎 FORCE conference coverage for bundled model/product announcements.
   - InfoQ / 36氪 / IT之家 / 机器之心 / 腾讯新闻 / 每经 / CSDN as secondary signals.
3. Treat Bing/Copilot summaries and search snippets as discovery leads, not final proof. Prefer official docs for exact model specs.
4. If a source is blocked, use accessible snippets carefully and label them as search-result signals.

## Reusable topic frames

- **豆包收费 / 会员分层**: “国产 AI 免费时代要结束了吗？” Good for普通用户利益点、评论区讨论。
- **GLM-5.2 1M 上下文 / Coding Agent**: “AI 编程从写函数到接管项目。” Use official facts: 1M context, 128K max output, project-level engineering, long-task/coding positioning.
- **Seedance 接入豆包 / AI 视频大众化**: “AI 视频从专业工具进入普通人工作流。” Good for自媒体/短视频创作者。
- **豆包 Coding / Agent 方向**: “字节抢 AI Coding 入口。” Best when FORCE coverage mentions Coding/Agent.
- **GLM-5.2 vs 豆包**: “国产大模型从参数战转向场景战。” Use when user wants one article covering GLM、豆包、Seedance together.
- **Seedance + Seedream + Seed-Audio**: “字节想把内容生产链路全包。” Good for内容生产/自媒体受众。

## Output shape

For each of 5-6 candidates include:

- 选题标题
- 为什么今天值得写
- 热度/来源依据
- 目标读者
- 传播钩子
- 3-5 个可选标题
- 推荐指数

End with: “你回复编号/标题，我再继续完整公众号流程。”
