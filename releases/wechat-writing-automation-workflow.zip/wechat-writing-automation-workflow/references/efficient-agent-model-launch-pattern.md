# Efficient Agent Model Launch Pattern

Use this reference when turning a major AI model launch into a WeChat Official Account article, especially for topics like Claude Sonnet 5 where the hook is **更强 Agent 能力 + 更低/更合理的日常使用成本**.

## Trigger topics

- Claude Sonnet / Gemini / GPT / Kimi / GLM / DeepSeek 主力模型更新
- "cheaper way to run agents" / "高能低耗" / "cost-performance" model launches
- A model is positioned as the new daily/default model, not necessarily the absolute strongest flagship
- User wants a full WeChat workflow: article + collage cover + baoyu-infographic + draft upload

## Fact boundaries

For model launches, avoid "全面最强 / 秒杀 / 必然更便宜" unless the official source says so.

Use conservative phrasing:

- "接近旗舰模型表现" rather than "替代旗舰模型"
- "部分任务/努力级别可匹配" rather than "全面碾压"
- "成本效率更好" rather than "一定更便宜"
- If official docs mention tokenizer or token-count changes, explain that real cost depends on input length, output length, effort level, and task type.

For Claude Sonnet 5 specifically, durable facts from the 2026-07-02 workflow:

- Official source: Anthropic `Introducing Claude Sonnet 5`
- Positioning: "most agentic Sonnet model yet"
- Capabilities: planning, tool use, browser/terminal use, coding, reasoning, knowledge work
- Framing: close to Opus 4.8 at lower prices, not a total Opus replacement
- Availability: all plans; Free/Pro default; Claude Code and Claude Platform available
- API name: `claude-sonnet-5`
- Intro pricing through 2026-08-31: $2/M input tokens, $10/M output tokens; later $3/M input, $15/M output
- Caveat: updated tokenizer can map the same input to ~1.0–1.35× tokens depending on content type
- Heat signal used: HN story around 1244 points / 773 comments; TechCrunch framed it as cheaper agents

Treat numeric heat signals as historical examples, not fresh current facts. Re-check live sources when the user asks for "today/latest".

## Best WeChat framing

Core angle:

> AI competition is moving from "who is smartest" to "who can complete real tasks stably at acceptable cost".

Reader-friendly metaphors:

- Flagship model = 顶配 Pro Max
- Daily Sonnet-class model = 性能强、续航好、天天用得起的主力机
- Token billing = 水电费 / 计量账单
- Agent model = 会规划、会用工具、会自检的 AI 实习生
- Human role = 管理者 / 副驾驶确认关键动作

Suggested article structure:

1. Hook: the important model is not always the most expensive flagship; it is the daily model people can afford to run.
2. What happened: official launch and positioning, with 2–3 verified facts.
3. What changed: planning, tool use, coding, knowledge work, default availability.
4. Explain "高能低耗": cost-performance, not "free" or "always cheaper".
5. Why normal users care: stable daily AI workflows, small tools, reports, coding help.
6. Beginner usage route: clear goal → break into steps → self-check → watch cost → human confirmation.
7. Ending question: do readers value strongest ability or stable/cost-effective completion?

## Title bank

- Claude Sonnet 5发布：AI主力模型进入“高能低耗”时代
- Claude Sonnet 5来了：以后AI干活，可能更强也更省
- AI主力模型变了：Claude Sonnet 5为什么值得普通人关注？
- 不只是更聪明，Claude Sonnet 5真正厉害的是更会干活
- 从聊天到办事，Claude Sonnet 5把Agent能力拉进日常使用

## Cover direction

Use `wechat-collage-cover` with native model typography first.

Recommended A-layer: `高能低耗`

B-layer: `Claude Sonnet 5发布`

Visual anchors:

- compact AI engine made of paper cards
- battery gauge / calculator tape / cost receipt
- workflow checklist
- browser / terminal / tool cards

Avoid:

- Real Anthropic or Claude logos
- Robot faces and generic blue-purple cyberpunk
- Long Chinese cover titles that increase typo risk

## Baoyu infographic stack

Use `dense-modules + craft-handmade`, 1080×608 final, 4K master archived.

### 1. Overview

Title: `Sonnet 5来了`
Subtitle: `主力模型更会干活`
Modules:
A 会计划
B 会用工具
C 会写代码
D 会查资料
E 成本更低
F 默认可用
Bottom: `不是只会聊天，而是更像AI实习生`

### 2. Cost-performance

Title: `高能低耗`
Subtitle: `强能力进入日常价位`
Modules:
A 接近Opus
B 低于旗舰价
C 中等任务更划算
D 努力级别可调
E Token要会算
F 按任务选模型
Bottom: `省钱不是少用AI，而是用对模型`

### 3. Beginner route

Title: `新手使用路线`
Subtitle: `先做可检查的小任务`
Modules:
A 写清目标
B 拆成步骤
C 让它自检
D 看成本账单
E 重要结果复核
F 留人工确认
Bottom: `把AI当副驾驶，不当自动驾驶`

## Upload/preflight reminders

- Keep body images as `real-baoyu-infographic` filenames.
- Do not use Markdown tables in the article body; convert structured comparisons into short paragraphs or infographics.
- Run `md-to-wechat.ts` and verify `contentImages`, `undefined:false`, `NaN:false`, and `WBIMGPH_:false` before upload.
- Reuse trusted `.baoyu-skills/.env` by copying; do not create secret files through `write_file`.
